<div class="footer" style="font-family:' Monaco', monospace ,Verdana, Geneva, sans-serif">
    <div class="footer_top" style="text-align:left;  float:left; width:100%; height:200px;" >
    	<div class="ft_top_3v">
        	
            <b>HỖ TRỢ KHÁCH HÀNG</b><br><br>
            
            Hotline: 1900-6035</a><br>
            (1000đ/phút , 8-21h kể cả T7, CN)<br>
           
            <a href="#">Hướng dẫn đặt hàng</a><br>
            <a href="#">Phương thức vận chuyển</a><br>
            <a href="#">Chính sách đổi trả</a><br>
            <a href="#">Hướng dẫn mua trả góp</a><br>

        </div>
        <div class="ft_top_3v">
        	
               <B> VỀ Men's Fahion</B><br><br>
                <a href="#">Giới thiệu MenFahion.com</a><br>
                <a href="#">Tuyển Dụng</a><br>
                <a href="#">Chính sách bảo mật</a><br>
                <a href="#">Điều khoản sử dụn</a>g<br>
               <a href="#"> Hội Sách Online</a><br>
               <a href="#"> Ưu đãi doanh nghiệp</a><br>

        </div>
        <div class="ft_top_3v">
        	
            <b>KẾT NỐI VỚI CHÚNG TÔI<b><br>
            <a href="https://www.facebook.com/"><IMG src="hinh_anh/tinymce/ic-fb.svg"></a>
            <a href="https://www.youtube.com/"><img src="hinh_anh/tinymce/ic-youtube.svg"></a>
            <a href="https://www.zalo.com/"><img src="hinh_anh/tinymce/ic-zalo.png" width="30px" height="30px"></a>
            
            <br>
            <br>
            	<b>TẢI ỨNG DỤNG TRÊN ĐIỆN THOẠI<b><br>
                <a href="#"><img src="hinh_anh/tinymce/appstore.png" title="app store " width="80px" height="40px;"></a>
                <a href="#"><img  src="hinh_anh/tinymce/google-play.png" title="google play" width="80px" height="40px;"></a>
            
        </div>
        
    </div>
    <div class="footer_bottom" style=" text-align:left; background:#777; height:30px; color:#fff; line-height:30px; font-weight:bold; float:left; width:100%;">
    	Copyright 2017 © Thời trang NAMFASHION.com

    </div>
</div>