
<form  >
	
    <input type="hidden" name="thamso" value="tim_kiem" >
    <input type="text" name="tu_khoa" value="" placeholder="Nhập tên sản phẩm" style=" color:#ccc;" >
    
    <button type="submit">Seach</button>
</form> 

